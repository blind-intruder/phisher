## MICROSOFT LOGIN PAGE CLONE

This is a clone of the iconic login page for Microsoft (outlook) accounts with its form validation.

> In as much as this script does not process information submitted, please do not submit any personal information!

> I DO NOT OWN the rights to any images used in this page!
### ✨TECH-STACK

- HTML
- CSS
- JavaScript
  
### 🔍 PREVIEW

Below is a short clip of what this clone looks like

<img src="assets/preview.gif" alt="preview" />