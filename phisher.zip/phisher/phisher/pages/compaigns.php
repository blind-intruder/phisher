<?php

include 'db/conn.php';

if(!isset($_SESSION["username"])){
    header("Location: ../login.php");
}
//new
$msg="";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
     if(isset($_POST["name"])){
        $name = mysqli_real_escape_string($conn, $_POST['name']);
        $sql = "INSERT INTO compaigns (name)
        VALUES ('".$name."')";

        if ($conn->query($sql) === TRUE) {
            $msg="<p style='color:green'>Compaign created!</p>";
        }
        else{
            $msg="<p style='color:red'>Unable to create compaign</p>";
        }
     }
}

        echo '<a href="#" class="btn btn-primary btn-icon-split" data-toggle="collapse" data-target="#collapseTwo"
                    aria-expanded="true" aria-controls="collapseTwo">
                                        <span class="icon text-white-50">
                                            <i class="fas fa-flag"></i>
                                        </span>
                                        <span class="text">New Compaign</span>
                                    </a>

<div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <form class="user" method="POST">
                                        <div class="form-group">
                                            <input type="text" class="form-control form-control-user"
                                                id="exampleInputEmail" name="name" aria-describedby="emailHelp"
                                                placeholder="Enter Name">
                                        </div>
                                        <button type="submit" name="submit" class="btn btn-primary btn-user btn-block">
                                            Create
                                        </button>
                                    </form>
                    </div>
                </div>
                    '.$msg.'
                                    <hr>

                                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Compaigns</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                        </tr>
                                    </thead>
                                    <tbody>';
                                    

        $sql = "SELECT * FROM compaigns";
        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) > 0) {
          // output data of each row
          while($row = mysqli_fetch_assoc($result)) {
                echo '<tr>
                            <td><a href=?include=reports.php&id='.$row["id"].'>'.$row["name"].'</a></td>
                        </tr>';
          }
        }

        echo '</tbody>
                                </table>
                            </div>
                        </div>
                    </div>';


?>
