<?php
$result='[1, [{"oth":{"st":"Success","m":"frmList"},"fact":{"3971367000000008004":{"sendId":"3971367000000008004","isVerified":"true","isZoho":"true","isAdminCustomSmtp":"false","mode":"0","isAlias":"false","defaut":"true","fromAddr":"arbab.jhangir@www-secp.pk","dispName":"Muhammad Arbab Jehangir","isAdminZohoSmtp":"false","group":"false","order":1,"isOauth":false}},"acLst":{"3971367000000008002":{"acId":"3971367000000008002","sendId":"3971367000000008004","eMail":"arbab.jhangir@www-secp.pk"}}}]]'; 
preg_match_all('/(?<=\"dispName\":)\"+[\w\s\d]+\"/', $result,  $match_found);
echo str_replace('"',"",$match_found[0][0])

//echo preg_replace("/[^0-9]/", '', $match_found[0][0]);
?> 