<?php
include 'db/conn.php';

function guidv4($data = null) {
    $data = $data ?? random_bytes(16);
    assert(strlen($data) == 16);
    $data[6] = chr(ord($data[6]) & 0x0f | 0x40);
    $data[8] = chr(ord($data[8]) & 0x3f | 0x80);
    return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
}

//globals
$acId = "";
$email = "";
$dispName = "";
$comp_id = "";
$template = "";
$title = "";
$url = "";
$uuid = guidv4();
$t=$arrayName = array('iamcsr' => $uuid);
$cookies = array();
$cookies = array_merge($cookies,  $t); 
//globals

function build_cookies( $query ){
    $query_array = array();
    foreach( $query as $key => $key_value ){
        $query_array[] = urlencode( $key ) . '=' . urlencode( $key_value );
    }
    return implode( '; ', $query_array );
}


function get_email_digest($email, $password){
	try {
	$ch = curl_init();
	$postvars = 'mode=primary&cli_time=&servicename=VirtualOffice&serviceurl=https%3A%2F%2Fmail.zoho.com%2Fzm%2F';
	$url = "https://accounts.zoho.com/signin/v2/lookup/".$email;
	curl_setopt($ch,CURLOPT_URL,$url);
	curl_setopt($ch,CURLOPT_POST, 1);               
	curl_setopt($ch,CURLOPT_POSTFIELDS,$postvars);
	curl_setopt($ch,CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch,CURLOPT_CONNECTTIMEOUT ,10);
	curl_setopt($ch, CURLOPT_HEADER, 1);
	curl_setopt($ch,CURLOPT_TIMEOUT, 20);

	curl_setopt(
	$ch, 
	CURLOPT_HTTPHEADER, 
	array(
	    'Referer: https://accounts.zoho.com/signin?servicename=VirtualOffice&serviceurl=https%3A%2F%2Fmail.zoho.com%2Fzm%2F', 
	    'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.5359.125 Safari/537.36', 
	    'Cookie: '.build_cookies($GLOBALS["cookies"]),
	    'X-Zcsrf-Token: iamcsrcoo='.$GLOBALS["cookies"]["iamcsr"] 
	)
	);
	$response = curl_exec($ch);
	$header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
	$header = substr($response, 0, $header_size);
	$body = substr($response, $header_size);
	//// Matching the response to extract cookies 
	preg_match_all('/^Set-Cookie:\s*([^;]*)/mi', $header,  $match_found);
	 
	foreach($match_found[1] as $item) { 
	    parse_str($item,  $cookie); 
	    $GLOBALS["cookies"] = array_merge($GLOBALS["cookies"],  $cookie); 
	} 
	$j=json_decode($body);
	curl_close($ch);
	login($j->lookup->identifier, $j->lookup->digest, $password);
	}
	catch (Exception $e) {
		curl_close($ch);
		echo "Email Digest Error";
	} 
}


function login($id, $digest, $password){
	try {
	$ch = curl_init();
	$postvars = '{"passwordauth":{"password":"'.$password.'"}}';
	$url = "https://accounts.zoho.com/signin/v2/primary/".$id."/password?digest=".$digest."&cli_time=&servicename=VirtualOffice&serviceurl=https%3A%2F%2Fmail.zoho.com%2Fzm%2F";
	curl_setopt($ch,CURLOPT_URL,$url);
	curl_setopt($ch,CURLOPT_POST, 1);              
	curl_setopt($ch,CURLOPT_POSTFIELDS,$postvars);
	curl_setopt($ch,CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch,CURLOPT_CONNECTTIMEOUT ,10);
	curl_setopt($ch, CURLOPT_HEADER, 1);
	curl_setopt($ch,CURLOPT_TIMEOUT, 20);

	curl_setopt(
	$ch, 
	CURLOPT_HTTPHEADER, 
	array(
	    'Referer: https://accounts.zoho.com/signin?servicename=VirtualOffice&serviceurl=https%3A%2F%2Fmail.zoho.com%2Fzm%2F', 
	    'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.5359.125 Safari/537.36', 
	    'Cookie: '.build_cookies($GLOBALS["cookies"]),
	    'X-Zcsrf-Token: iamcsrcoo='.$GLOBALS["cookies"]["iamcsr"] 
	)
	);
	$response = curl_exec($ch);

	$header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
	$header = substr($response, 0, $header_size);
	$body = substr($response, $header_size);
	//// Matching the response to extract cookies 
	preg_match_all('/^Set-Cookie:\s*([^;]*)/mi', $header,  $match_found);
	 
	foreach($match_found[1] as $item) { 
	    parse_str($item,  $cookie); 
	    $GLOBALS["cookies"] = array_merge($GLOBALS["cookies"],  $cookie); 
	} 
	curl_close($ch);
	//echo "<!--".$body."-->";
	get_zm_token();
	}
	catch (Exception $e) {
		curl_close($ch);
		echo "Login Error";
	}
}

function get_zm_token(){
	try {
	$ch = curl_init();
	$url = "https://mail.zoho.com/zm/";
	curl_setopt($ch,CURLOPT_URL,$url);
	curl_setopt($ch,CURLOPT_POST, 0);              
	curl_setopt($ch,CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch,CURLOPT_CONNECTTIMEOUT ,10);
	curl_setopt($ch, CURLOPT_HEADER, 1);
	curl_setopt($ch,CURLOPT_TIMEOUT, 20);

	curl_setopt(
	$ch, 
	CURLOPT_HTTPHEADER, 
	array(
	    'Referer: https://accounts.zoho.com/', 
	    'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.5359.125 Safari/537.36', 
	    'Cookie: '.build_cookies($GLOBALS["cookies"])
	)
	);
	$response = curl_exec($ch);

	$header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
	$header = substr($response, 0, $header_size);
	$body = substr($response, $header_size);
	//// Matching the response to extract cookies 
	preg_match_all('/^Set-Cookie:\s*([^;]*)/mi', $header,  $match_found);
	 
	foreach($match_found[1] as $item) { 
	    parse_str($item,  $cookie); 
	    $GLOBALS["cookies"] = array_merge($GLOBALS["cookies"],  $cookie); 
	} 
	curl_close($ch);
	//echo "<!--".$body."-->";
	get_email();
	}
	catch (Exception $e) {
		curl_close($ch);
		echo "Login Error";
	}
}

function get_email(){
	try {
	$ch = curl_init();
	$postvars = 'mode=frmList';
	$url = "https://mail.zoho.com/zm/sendMailAs.do";
	curl_setopt($ch,CURLOPT_URL,$url);
	curl_setopt($ch,CURLOPT_POST, 1);              
	curl_setopt($ch,CURLOPT_POSTFIELDS,$postvars);
	curl_setopt($ch,CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch,CURLOPT_CONNECTTIMEOUT ,10);
	curl_setopt($ch, CURLOPT_HEADER, 1);
	curl_setopt($ch,CURLOPT_TIMEOUT, 20);

	curl_setopt(
	$ch, 
	CURLOPT_HTTPHEADER, 
	array(
	    'Referer: https://accounts.zoho.com/signin?servicename=VirtualOffice&serviceurl=https%3A%2F%2Fmail.zoho.com%2Fzm%2F', 
	    'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.5359.125 Safari/537.36', 
	    'Cookie: '.build_cookies($GLOBALS["cookies"]),
	    'X-Zcsrf-Token: zmrcsr='.$GLOBALS["cookies"]["zmcsr"] 
	)
	);
	$response = curl_exec($ch);

	$header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
	$header = substr($response, 0, $header_size);
	$body = substr($response, $header_size);
	//// Matching the response to extract cookies 
	preg_match_all('/^Set-Cookie:\s*([^;]*)/mi', $header,  $match_found);
	 
	foreach($match_found[1] as $item) { 
	    parse_str($item,  $cookie); 
	    $GLOBALS["cookies"] = array_merge($GLOBALS["cookies"],  $cookie); 
	} 
	curl_close($ch);
	//echo "<!--".$body."-->";
	preg_match_all('/\"acId\":\"+[0-9]+\"/', $body,  $match_found);
	$GLOBALS["acId"] = preg_replace("/[^0-9]/", '', $match_found[0][0]);

	preg_match_all('/[\w\-\.]+@([\w\-]+\.)+[\w\-]{2,4}/', $body,  $match_found);
	$GLOBALS["email"] = $match_found[0][0];

	preg_match_all('/(?<=\"dispName\":)\"+[\w\s\d]+\"/', $body,  $match_found);
	$GLOBALS["dispName"] = str_replace('"',"",$match_found[0][0]);
	fetch_targets();
	}
	catch (Exception $e) {
		curl_close($ch);
		echo "Fetch Email Error";
	}
}


function fetch_targets(){
	$sql = "SELECT * FROM targets where compaign_id='".$GLOBALS["comp_id"]."' and status='Pending'";
        $result = mysqli_query($GLOBALS["conn"], $sql);

        if (mysqli_num_rows($result) > 0) {
          while($row = mysqli_fetch_assoc($result)) {
          	send_email('"'.$row["first_name"].' '.$row["last_name"].'" <'.$row["email"].'>', $row["first_name"]." ".$row["last_name"], $row["id"], $row["email"]);
          	sleep(3);
          }
      }
}


function send_email($to, $name, $id, $v_email){
	try {
	$ch = curl_init();
	$temp = base64_decode($GLOBALS["template"]);
	$url = $GLOBALS["url"]."?cache_xray_id=".$v_email."&cache_xray_uid=".$GLOBALS["comp_id"];
	$temp = str_replace("{url}",$GLOBALS["url"],$temp);
	$temp = str_replace("{name}",$name,$temp);
	$postvars = 'accId='.$GLOBALS["acId"].'&originalMode=compose&from="'.$GLOBALS["dispName"].'"+<'.$GLOBALS["email"].'>&to='.urlencode($to).'&cc=&bcc=&sendImm=true&subject='.urlencode($GLOBALS["title"]).'&content='.urlencode($temp).'&smType=2&charSet=UTF-8&replyTo=&priority=Medium';
	$url = "https://mail.zoho.com/zm/send.do";
	curl_setopt($ch,CURLOPT_URL,$url);
	curl_setopt($ch,CURLOPT_POST, 1);              
	curl_setopt($ch,CURLOPT_POSTFIELDS,$postvars);
	curl_setopt($ch,CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch,CURLOPT_CONNECTTIMEOUT ,10);
	curl_setopt($ch, CURLOPT_HEADER, 1);
	curl_setopt($ch,CURLOPT_TIMEOUT, 20);

	curl_setopt(
	$ch, 
	CURLOPT_HTTPHEADER, 
	array(
	    'Referer: https://accounts.zoho.com/signin?servicename=VirtualOffice&serviceurl=https%3A%2F%2Fmail.zoho.com%2Fzm%2F', 
	    'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.5359.125 Safari/537.36', 
	    'Cookie: '.build_cookies($GLOBALS["cookies"]),
	    'X-Zcsrf-Token: zmrcsr='.$GLOBALS["cookies"]["zmcsr"] 
	)
	);
	$response = curl_exec($ch);

	$header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
	$header = substr($response, 0, $header_size);
	$body = substr($response, $header_size);
	//// Matching the response to extract cookies 
	preg_match_all('/^Set-Cookie:\s*([^;]*)/mi', $header,  $match_found);
	 
	foreach($match_found[1] as $item) { 
	    parse_str($item,  $cookie); 
	    $GLOBALS["cookies"] = array_merge($GLOBALS["cookies"],  $cookie); 
	} 
	echo "<!--".$body."-->";
	curl_close($ch);//msgId
	if (str_contains($body, 'msgId')) {
		echo "Email Sent";
		$sql = "UPDATE targets SET status='Sent' WHERE id=".$id;
		if ($GLOBALS["conn"]->query($sql) === TRUE) {

		}
	}
	else{
		echo "Email not Sent";
	}
	}
	catch (Exception $e) {
		curl_close($ch);
		echo "Fet Email Error";
	}
}

function start(){
	//$compaign_id = "4"; //dynamic in future
	$argv = $GLOBALS["argv"];
	$compaign_id = $argv[1];
	$sql = "SELECT * FROM phishing where compaign_id='".$compaign_id."'";
        $result = mysqli_query($GLOBALS["conn"], $sql);

        if (mysqli_num_rows($result) > 0) {
          // output data of each row
        	$out="";
        	$zm_email = "";
        	$zm_password = "";
          while($row = mysqli_fetch_assoc($result)) {
          	$GLOBALS["comp_id"] = $row["compaign_id"];
          	$GLOBALS["template"] = $row["template"];
          	$GLOBALS["url"] = $row["url"];
          	$GLOBALS["title"] = $row["title"];
          	$zm_email = $row["zm_email"];
          	$zm_password = $row["zm_password"];
          }
          get_email_digest($zm_email, $zm_password);
        }
}

start();
//print_r($argv);
?>